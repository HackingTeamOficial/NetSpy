package main

import (
	"netspy/core"
)

func main() {
	core.Execute()
}
